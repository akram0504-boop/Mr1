'use strict';
const kv = require('../lib/kv');
const A = require('../lib/auth');
const C = require('../lib/core');
const wrap = require('../lib/http');

const riyadhMin = () => { const p = new Intl.DateTimeFormat('en-GB', { timeZone: 'Asia/Riyadh', hour: '2-digit', minute: '2-digit', hour12: false }).formatToParts(new Date()); return (+p.find(x => x.type === 'hour').value % 24) * 60 + +p.find(x => x.type === 'minute').value; };
const inHours = u => { if (!u.allowFrom || !u.allowTo) return true; const m = riyadhMin(), f = s => { const x = String(s).split(':'); return +x[0] * 60 + (+x[1] || 0); }, a = f(u.allowFrom), b = f(u.allowTo); return a <= b ? (m >= a && m <= b) : (m >= a || m <= b); };

module.exports = wrap(async (req) => {
  if (req.method !== 'POST') throw new C.HttpErr(405, 'غير مسموح');
  if (!A.SECRET_OK()) throw new C.HttpErr(503, A.SECRET_WHY());
  const ip = C.ipOf(req);
  if ((await kv.hit('rl:login:' + ip, 600)) > 30) throw new C.HttpErr(429, 'محاولات كثيرة من هذا الجهاز. انتظر قليلاً.');
  const ND = x => String(x == null ? '' : x).replace(/[٠-٩]/g, d => d.charCodeAt(0) - 0x660).replace(/[۰-۹]/g, d => d.charCodeAt(0) - 0x6F0).trim();
  const user = ND(req.body.user).toLowerCase().slice(0, 40), pin = ND(req.body.pin);
  if (!user || !pin || pin.length > 40) throw new C.HttpErr(400, 'أدخل اسم المستخدم والرمز');
  const cfg = await C.getCfg(), sec = Object.assign({ maxFails: 5, lockMin: 5 }, cfg.sec || {});
  let list = await kv.hgetall('col:staff');
  if (!list.length) {
    const ap = ND(process.env.ADMIN_PIN);
    if (!ap) throw new C.HttpErr(503, 'لم يُضبط ADMIN_PIN على الخادم لإنشاء حساب المدير الأول');
    if (!/^\d{6,12}$/.test(ap) || A.weakPin(ap)) throw new C.HttpErr(503, 'ADMIN_PIN ضعيف أو منشور: استخدم 6 أرقام فأكثر غير متسلسلة ولا مكررة ولا مثالاً مكتوباً في المحادثة');
    if (user === 'admin' && pin === ap) {
      const m = { id: 's-admin', name: 'المدير', user: 'admin', pin: A.hashPin(ap), sv: 0, role: 'manager', mustChange: true, active: true, createdAt: Date.now() };
      await C.put('staff', m.id, m); list = [m];
    }
  }
  const acc = list.find(x => x.user === user);
  if (acc && acc.lockUntil && acc.lockUntil > Date.now()) throw new C.HttpErr(429, 'الحساب مقفل مؤقتاً بسبب محاولات خاطئة. حاول بعد ' + Math.ceil((acc.lockUntil - Date.now()) / 60000) + ' دقيقة.');
  if (!acc) A.dummyCheck(pin); // same cost for unknown users: no user enumeration by timing
  if (!acc || !A.checkPin(pin, acc.pin)) {
    if (acc) {
      const f = (acc.fails || 0) + 1, pt = f >= sec.maxFails ? { fails: 0, lockUntil: Date.now() + sec.lockMin * 60000 } : { fails: f };
      const { id, ...rest } = acc; await C.put('staff', acc.id, Object.assign(rest, pt));
      if (pt.lockUntil) { const aid = C.rid('a'); await C.put('audit', aid, { id: aid, ts: Date.now(), by: '—', act: 'قفل حساب بسبب محاولات خاطئة', detail: acc.user }); }
    }
    // monitoring: a burst of failures from one device is written to the audit log (once per burst)
    const n = await kv.hit('fail:' + ip, 900);
    if (n === 6) { const aid = C.rid('a'); console.warn('[security] repeated failed logins', ip); await C.put('audit', aid, { id: aid, ts: Date.now(), by: '—', act: 'محاولات دخول فاشلة متكررة', detail: 'المستخدم: ' + C.clip(user, 20) + ' · الجهاز: ' + ip.replace(/(\d+)$/, '•••') }); }
    throw new C.HttpErr(401, 'اسم المستخدم أو الرمز غير صحيح.');
  }
  if (acc.active === false) throw new C.HttpErr(403, 'هذا الحساب موقوف. تواصل مع المدير.');
  if (acc.role !== 'manager' && !inHours(acc)) throw new C.HttpErr(403, 'الدخول غير مسموح لحسابك في هذا الوقت.');
  const { id, ...rest } = acc;
  const upd = Object.assign(rest, { fails: 0, lockUntil: 0, lastLogin: Date.now() });
  await C.put('staff', acc.id, upd);
  const aid = C.rid('a'); await C.put('audit', aid, { id: aid, ts: Date.now(), by: acc.name, act: 'تسجيل دخول', detail: acc.user });
  return { token: A.sign(acc.id, acc.sv || 0), user: A.pub(Object.assign({ id: acc.id }, upd)) };
});
