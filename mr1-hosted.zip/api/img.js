'use strict';
const kv = require('../lib/kv');
const A = require('../lib/auth');
const C = require('../lib/core');
const wrap = require('../lib/http');
module.exports = wrap(async (req, res) => {
  if (req.method === 'GET') {
    const id = String((req.query || {}).id || '');
    if (!/^i[a-z0-9]{6,30}$/.test(id)) throw new C.HttpErr(404, 'غير موجود');
    const d = await kv.hget('col:img', id);
    if (!d) throw new C.HttpErr(404, 'غير موجود');
    res.setHeader('content-type', d.mime); res.setHeader('cache-control', 'public, max-age=31536000, immutable');
    res.setHeader('content-security-policy', "default-src 'none'; sandbox"); res.setHeader('content-disposition', 'inline');
    res.status(200).end(Buffer.from(d.b64, 'base64')); return;
  }
  if (req.method !== 'POST') throw new C.HttpErr(405, 'غير مسموح');
  const u = await A.me(req);
  if (!u || u.role !== 'manager' || u.mustChange) throw new C.HttpErr(403, 'للمدير فقط');
  const m = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(String(req.body.data || ''));
  if (!m) throw new C.HttpErr(400, 'صيغة الصورة غير مدعومة');
  if (m[2].length > 480000) throw new C.HttpErr(413, 'الصورة كبيرة، اختر صورة أصغر');
  const buf = Buffer.from(m[2], 'base64'), hx = buf.slice(0, 12);
  const okMagic = m[1] === 'image/jpeg' ? (hx[0] === 0xFF && hx[1] === 0xD8 && hx[2] === 0xFF)
    : m[1] === 'image/png' ? hx.slice(0, 8).equals(Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]))
    : (hx.slice(0, 4).toString('latin1') === 'RIFF' && hx.slice(8, 12).toString('latin1') === 'WEBP');
  if (!okMagic || buf.length < 100) throw new C.HttpErr(400, 'الملف ليس صورة صالحة');
  const id = C.rid('i');
  await kv.hset('col:img', id, { mime: m[1], b64: m[2] });
  return { url: '/api/img?id=' + id };
});
