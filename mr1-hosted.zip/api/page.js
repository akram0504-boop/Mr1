'use strict';
// Serves the app page with a Content-Security-Policy computed from the page itself:
// only the exact inline <script> blocks that ship with the page may run.
const fs = require('fs'), path = require('path'), crypto = require('crypto');
let cache = null;
function build() {
  let html; try { html = fs.readFileSync(path.join(__dirname, '..', 'views', 'index.html'), 'utf8'); } catch (e) { html = fs.readFileSync(path.join(process.cwd(), 'views', 'index.html'), 'utf8'); }
  const hashes = [];
  html.replace(/<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/gi, (m, code) => { hashes.push("'sha256-" + crypto.createHash('sha256').update(code, 'utf8').digest('base64') + "'"); return m; });
  const csp = [
    "default-src 'none'",
    'script-src ' + (hashes.join(' ') || "'none'"),
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "font-src https://fonts.gstatic.com",
    "img-src 'self' data: blob:",
    "connect-src 'self'",
    "manifest-src 'self'",
    "base-uri 'none'",
    "form-action 'self'",
    "frame-ancestors 'none'",
    "object-src 'none'",
    'upgrade-insecure-requests',
  ].join('; ');
  return { html, csp };
}
module.exports = (req, res) => {
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.statusCode = 405; return res.end(); }
  cache = cache || build();
  res.setHeader('content-type', 'text/html; charset=utf-8');
  res.setHeader('content-security-policy', cache.csp);
  res.setHeader('cache-control', 'no-cache');
  res.setHeader('x-content-type-options', 'nosniff');
  res.statusCode = 200;
  res.end(req.method === 'HEAD' ? undefined : cache.html);
};
