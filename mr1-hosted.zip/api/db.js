'use strict';
const kv = require('../lib/kv');
const A = require('../lib/auth');
const C = require('../lib/core');
const wrap = require('../lib/http');
const { HttpErr } = C;
const err = (s, m, c) => new HttpErr(s, m, c);
const pick = (o, keys) => Object.fromEntries(Object.keys(o).filter(k => keys.includes(k)).map(k => [k, o[k]]));
const ORDER_KEYS = ['status', 'paid', 'payMethod', 'invoice', 'paidAt', 'paidBy', 'paidById', 'sentAt', 'prepAt', 'readyAt', 'doneAt', 'updatedAt', 'by'];
const RES_KEYS = ['status', 'depPaid', 'updatedAt', 'by'];

async function minPin() { const c = await C.getCfg(); const m = +((c.sec || {}).minPin) || 6; return Math.min(12, Math.max(6, m)); }
async function pinChecked(pin) {
  const m = await minPin();
  if (!new RegExp('^\\d{' + m + ',12}$').test(String(pin))) throw err(400, 'الرمز من ' + m + ' إلى 12 رقماً');
  if (A.weakPin(String(pin))) throw err(400, 'الرمز سهل التخمين (متسلسل أو مكرر). اختر رمزاً آخر.');
  return A.hashPin(String(pin));
}
const activeManagers = (list, exceptId) => list.filter(x => x.role === 'manager' && x.active !== false && x.id !== exceptId).length;

/* ---------------- reads ---------------- */
async function read(req, user) {
  const q = req.query || {}, col = String(q.col || ''), id = q.id ? String(q.id) : '';
  if (!C.COLS.includes(col)) throw err(400, 'مجموعة غير معروفة');
  const cur = await kv.getn('rev:' + col);
  if (String(q.rev || '') === String(cur) && q.rev !== undefined && q.rev !== '') return { same: true, rev: cur };
  // public reads: the shop configuration, and a single order/reservation by its random id
  if (col === 'config') { let d = await kv.hget('col:config', 'menu'); if (d && !(user && user.role === 'manager' && !user.mustChange)) { d = Object.assign({}, d); delete d.sec; delete d.botNotes; delete d.botFaq; } return id ? { rev: cur, doc: d } : { rev: cur, docs: d ? [Object.assign({ id: 'menu' }, d)] : [] }; }
  if ((col === 'orders' || col === 'reservations') && id) { const d = await kv.hget('col:' + col, id); return { rev: cur, doc: d ? Object.assign({ id }, d) : null }; }
  if (!user) throw err(401, 'يلزم تسجيل الدخول', 'auth');
  if (user.mustChange) throw err(403, 'غيّر رمزك أولاً', 'must_change');
  if (col === 'orders') {
    if (!['orders', 'kitchen', 'payments', 'manageOrders', 'kitchenActions'].some(k => A.can(user, k))) throw err(403, 'غير مسموح');
    let docs = await kv.hgetall('col:orders');
    if (user.role === 'staff') docs = docs.filter(o => !o.waiterId || o.waiterId === user.id);
    return { rev: cur, docs };
  }
  if (col === 'reservations') {
    if (!A.can(user, 'res') && !A.can(user, 'manageRes')) throw err(403, 'غير مسموح');
    let docs = await kv.hgetall('col:reservations');
    if (!A.can(user, 'phones')) docs = docs.map(r => Object.assign(r, { phone: String(r.phone).slice(0, 3) + '•••••' + String(r.phone).slice(-2) }));
    return { rev: cur, docs };
  }
  if (user.role !== 'manager') throw err(403, 'للمدير فقط');
  const docs = await kv.hgetall('col:' + col);
  return { rev: cur, docs: col === 'staff' ? docs.map(A.pub) : docs };
}

/* ---------------- writes ---------------- */
async function write(req, user) {
  const { op, col, id } = req.body, doc = req.body.doc;
  if (!C.COLS.includes(col) || !['set', 'merge', 'del'].includes(op) || typeof id !== 'string' || !C.ID_OK.test(id)) throw err(400, 'طلب غير صحيح');
  if (JSON.stringify(doc || {}).length > 200000) throw err(413, 'البيانات كبيرة جداً');
  const ip = C.ipOf(req), mgr = user && user.role === 'manager';
  if (user && user.mustChange) {
    const keys = Object.keys(doc || {});
    if (!(col === 'staff' && op === 'merge' && id === user.id && keys.length && keys.every(k => ['pin', 'mustChange'].includes(k)))) throw err(403, 'غيّر رمزك أولاً', 'must_change');
  }
  const cfg = await C.getCfg();

  if (col === 'orders') {
    if (op === 'set') { await C.createOrder(cfg, doc || {}, ip); return { ok: true }; }
    const canStaff = user && ['manageOrders', 'payments', 'kitchenActions', 'cancelOrders'].some(k => A.can(user, k));
    if (op === 'del') { if (!mgr) throw err(403, 'للمدير فقط'); await C.del('orders', id); return { ok: true }; }
    if (!canStaff) { await C.customerOrderPatch(cfg, id, doc || {}); return { ok: true }; }
    const cur = await kv.hget('col:orders', id); if (!cur) throw err(404, 'الطلب غير موجود');
    const p = pick(doc || {}, ORDER_KEYS), now = Date.now();
    if (!Object.keys(p).length) throw err(400, 'لا يوجد ما يُحدَّث');
    if (p.status === 'cancel' && !A.can(user, 'cancelOrders')) throw err(403, 'ليست لديك صلاحية الإلغاء');
    if ((p.status === 'sent' || p.status === 'done') && !A.can(user, 'manageOrders')) throw err(403, 'ليست لديك صلاحية');
    if ((p.status === 'prep' || p.status === 'ready') && !(A.can(user, 'kitchenActions') || A.can(user, 'manageOrders'))) throw err(403, 'ليست لديك صلاحية');
    if (p.paid !== undefined || p.invoice !== undefined || p.payMethod !== undefined) {
      if (!A.can(user, 'payments')) throw err(403, 'ليست لديك صلاحية تأكيد الدفع');
      if (p.paid && !/^[A-Za-z0-9\-\/_.]{1,30}$/.test(String(p.invoice || ''))) throw err(400, 'رقم الفاتورة مطلوب (أرقام أو حروف إنجليزية)');
      if (p.invoice) {
        const dup = (await kv.hgetall('col:orders')).some(o => o.id !== id && o.invoice === p.invoice);
        if (dup) throw err(409, 'رقم الفاتورة مستخدم لطلب آخر.');
      }
      if (p.paid) Object.assign(p, { paidBy: user.name, paidById: user.id, paidAt: now });
    }
    if (p.status === 'sent' && cfg.payFirst !== false && !(cur.paid || p.paid)) throw err(400, 'أكّد الدفع أولاً');
    p.updatedAt = now; p.by = user.name;
    await C.put('orders', id, Object.assign(cur, p)); return { ok: true };
  }

  if (col === 'reservations') {
    if (op === 'set') { await C.createReservation(cfg, doc || {}, ip, ''); return { ok: true }; }
    if (op === 'del') { if (!mgr) throw err(403, 'للمدير فقط'); await C.del('reservations', id); return { ok: true }; }
    if (!(user && A.can(user, 'manageRes'))) { await C.customerResPatch(id, doc || {}); return { ok: true }; }
    const cur = await kv.hget('col:reservations', id); if (!cur) throw err(404, 'الحجز غير موجود');
    const p = pick(doc || {}, RES_KEYS); p.updatedAt = Date.now(); p.by = user.name;
    await C.put('reservations', id, Object.assign(cur, p)); return { ok: true };
  }

  if (!user) throw err(401, 'يلزم تسجيل الدخول', 'auth');

  if (col === 'audit') {
    if (op === 'del') { if (!mgr) throw err(403, 'للمدير فقط'); await C.del('audit', id); return { ok: true }; }
    const aid = C.rid('a'); await C.put('audit', aid, { id: aid, ts: Date.now(), by: user.name, act: C.clip((doc || {}).act, 80), detail: C.clip((doc || {}).detail, 160) }); return { ok: true };
  }

  if (col === 'staff') {
    const list = await kv.hgetall('col:staff'), tgt = list.find(x => x.id === id), d = doc || {};
    const selfPin = id === user.id && op === 'merge' && Object.keys(d).length && Object.keys(d).every(k => ['pin', 'mustChange'].includes(k));
    if (selfPin) {
      if (!d.pin) throw err(400, 'الرمز مطلوب');
      const { id: _i, ...rest } = tgt; Object.assign(rest, { pin: await pinChecked(d.pin), mustChange: false, fails: 0, lockUntil: 0, sv: (tgt.sv || 0) + 1 });
      await C.put('staff', id, rest); return { ok: true, token: A.sign(id, rest.sv) };
    }
    if (!mgr) throw err(403, 'للمدير فقط');
    if (op === 'del') {
      if (!tgt) return { ok: true };
      if (id === user.id) throw err(400, 'لا يمكنك حذف حسابك');
      if (tgt.role === 'manager' && !activeManagers(list, id)) throw err(400, 'لا يمكن حذف آخر مدير');
      await C.del('staff', id); return { ok: true };
    }
    const ROLES = ['manager', 'staff', 'kitchen'];
    if (op === 'set') {
      if (tgt) throw err(409, 'الحساب موجود');
      if (list.length >= 10) throw err(400, 'الحد الأقصى 10 مستخدمين');
      if (!/^[a-z0-9_.-]{3,20}$/.test(String(d.user || '')) || list.some(x => x.user === d.user)) throw err(400, 'اسم المستخدم غير صالح أو مستخدم من قبل');
      if (!ROLES.includes(d.role)) throw err(400, 'دور غير صحيح');
      const nd = { name: C.clip(d.name, 30), user: d.user, role: d.role, pin: await pinChecked(d.pin), sv: 0, mustChange: true, active: true, perms: d.perms && typeof d.perms === 'object' ? pick(d.perms, ['orders', 'manageOrders', 'cancelOrders', 'payments', 'kitchen', 'kitchenActions', 'res', 'manageRes', 'phones', 'stats']) : {}, createdAt: Date.now() };
      await C.put('staff', id, nd); return { ok: true };
    }
    if (!tgt) throw err(404, 'الحساب غير موجود');
    const { id: _i, ...rest } = tgt, p = pick(d, ['name', 'role', 'active', 'perms', 'allowFrom', 'allowTo', 'keepAlive', 'sound', 'mustChange', 'pin', 'fails', 'lockUntil']);
    if (p.role && !ROLES.includes(p.role)) throw err(400, 'دور غير صحيح');
    const nextRole = p.role || tgt.role, nextActive = p.active !== undefined ? p.active : tgt.active !== false;
    if (tgt.role === 'manager' && (nextRole !== 'manager' || !nextActive) && !activeManagers(list, id)) throw err(400, 'يجب بقاء مدير نشط واحد على الأقل');
    if (id === user.id && !nextActive) throw err(400, 'لا يمكنك إيقاف حسابك');
    if (p.name !== undefined) p.name = C.clip(p.name, 30);
    if (p.pin) { p.pin = await pinChecked(p.pin); p.fails = 0; p.lockUntil = 0; p.sv = (tgt.sv || 0) + 1; if (id !== user.id) p.mustChange = true; } else delete p.pin;
    await C.put('staff', id, C.dm(rest, p)); return p.pin && id === user.id ? { ok: true, token: A.sign(id, p.sv) } : { ok: true };
  }

  if (col === 'config') {
    if (!mgr) throw err(403, 'للمدير فقط');
    if (id !== 'menu') throw err(400, 'مجموعة غير صحيحة');
    if (op === 'del') throw err(400, 'غير مسموح');
    const cur = (await kv.hget('col:config', 'menu')) || {};
    const nd = op === 'set' ? (doc || {}) : C.dm(cur, doc || {});
    if (JSON.stringify(nd).length > 250000) throw err(413, 'الإعدادات كبيرة جداً');
    await C.put('config', 'menu', nd); return { ok: true };
  }
  throw err(400, 'غير مسموح');
}

module.exports = wrap(async (req) => {
  const user = await A.me(req);
  if (req.method === 'GET') return read(req, user);
  if (req.method === 'POST') return write(req, user);
  throw err(405, 'غير مسموح');
});
