'use strict';
const A = require('../lib/auth');
const C = require('../lib/core');
const wrap = require('../lib/http');
module.exports = wrap(async (req) => {
  const u = await A.me(req);
  if (!u) throw new C.HttpErr(401, 'انتهت الجلسة', 'auth');
  return { user: A.pub(u) };
});
