'use strict';
// Local test server: in-memory storage + a fake Anthropic API. Run: MR1_MEM=1 ADMIN_PIN=123456 node dev-server.js
process.env.MR1_MEM = process.env.MR1_MEM || '1';
process.env.ADMIN_PIN = process.env.ADMIN_PIN || '482915';
const http = require('http'), fs = require('fs'), path = require('path');
const PORT = +process.env.PORT || 3100;
if (process.env.FAKE_AI === '1') {
  process.env.ANTHROPIC_API_KEY = 'fake'; process.env.ANTHROPIC_BASE_URL = 'http://127.0.0.1:' + (PORT + 1);
  http.createServer((req, res) => { let b = ''; req.on('data', d => b += d); req.on('end', () => {
    const j = JSON.parse(b), last = j.messages[j.messages.length - 1]; res.setHeader('content-type', 'application/json');
    global.__lastSystem = j.system;
    if (Array.isArray(last.content) && last.content[0].type === 'tool_result') return res.end(JSON.stringify({ stop_reason: 'end_turn', content: [{ type: 'text', text: 'تم الحجز: ' + last.content[0].content }] }));
    if (/نعم/.test(String(last.content))) { const d = new Date(Date.now() + 2 * 864e5).toISOString().slice(0, 10); return res.end(JSON.stringify({ stop_reason: 'tool_use', content: [{ type: 'tool_use', id: 't1', name: 'create_reservation', input: { name: 'فهد', phone: '0555555555', guests: 4, date: d, time: '21:00' } }] })); }
    res.end(JSON.stringify({ stop_reason: 'end_turn', content: [{ type: 'text', text: 'جواب تجريبي. ' + (/محمد عبده/.test(j.system) ? 'الفنان موجود في البيانات' : 'لا فنان') }] }));
  }); }).listen(PORT + 1);
}
const routes = { page: require('./api/page'), db: require('./api/db'), login: require('./api/login'), me: require('./api/me'), img: require('./api/img'), bot: require('./api/bot') };
http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x');
  res.status = c => { res.statusCode = c; return res; };
  res.json = o => { res.setHeader('content-type', 'application/json'); res.end(JSON.stringify(o)); };
  const m = /^\/api\/(\w+)/.exec(u.pathname);
  if (m && routes[m[1]]) {
    let b = ''; req.on('data', d => b += d); req.on('end', () => {
      req.query = Object.fromEntries(u.searchParams); try { req.body = b ? JSON.parse(b) : {}; } catch (e) { req.body = {}; }
      routes[m[1]](req, res);
    }); return;
  }
  routes.page(req, res);
}).listen(PORT, () => console.log('http://127.0.0.1:' + PORT));
